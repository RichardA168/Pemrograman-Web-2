<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>index.php</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
      body{
        background-image:url("../bg1.jpg");
        background-size:cover;
        background-attachment:fixed;
        background-repeat:no-repeat;
      }
      img{
        width: 30%;
        object-fit: cover;
        object-position: center;
      }
      header{
        padding:5px;
      }
    </style>
  </head>
  <body>
    
    <div class="w3-container">

      <div class="w3-card-4 w3-pale-green w3-center w3-text-teal" style="width:50%; margin: 230px auto;">
      <header class="w3-teal w3-border-bottom w3-border-white w3-text-white">
      <h1>Biodata Mahasiswa</h1>
      </header>

          <div class="w3-container" style="padding:40px">
            <img src="../Ganteng.jpg" alt="Richard Alexander" class="w3-left w3-margin-right">
            <h2><?= $nama ?></h2>
            <h3><?= $nim ?></h3>

          <div class="w3-section">
          <form action="/Home/biodata">
            <button class="w3-button w3-green">More Info...</button>
          </form>
          </div>
        
          </div>
      </div>
  </div>
  
  </body>
</html>