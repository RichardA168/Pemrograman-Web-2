<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title>biodata.php</title>
    <style>
      body{
        background-image:url("../bg1.jpg");
        background-size:cover;
        background-attachment:fixed;
        background-repeat:no-repeat;
      }
      img{
        width: 20%;
        object-fit: cover;
        object-position: center;
      }
      header{
        padding:5px;
      }
      td{
        color:teal;
      }
      p{
        color:teal;
      }
    </style>
</head>
    <body>
        <div class="w3-container">

        <div class="w3-card-4" style="width:70%; margin: 230px auto;">
            <header class="w3-teal w3-center w3-border-bottom w3-border-white w3-text-white">
                <h1>Biodata Mahasiswa</h1>
            </header>
            <div class="w3-container w3-pale-green" style="padding:40px">
            <img src="../Ganteng.jpg" alt="Richard Alexander" class="w3-left w3-margin-right">
                <table>
                    <tr>
                        <td>NAMA</td>
                        <td>: <?= $nama ?></td>
                    </tr>
                    <tr>
                        <td>NIM</td>
                        <td>: <?= $nim ?></td>
                    </tr>
                    <tr>
                        <td>PRODI</td>
                        <td>: <?= $prodi ?></td>
                    </tr>
                    <tr>
                        <td>HOBI</td>
                        <td>: <?= $hobi ?></td>
                    </tr>
                    <tr>
                        <td>SKILL</td>
                        <td>: <?= $skill ?></td>
                    </tr>
                </table>
                <p>
                    Perkenalkan, Saya <?= $nama ?> dengan NIM <?= $nim ?> yang sekarang berada di prodi <?= $prodi ?>.
                    Saya memiliki hobi yaitu <?= $hobi ?> dan skill yaitu <?= $skill ?>. Senang berkenalan dengan kalian!
                </p>
                <br>
                <div class="w3-section w3-right w3-margin-left">
                    <form action="/Home/index">
                        <button class="w3-button w3-red">Kembali</button>
                    </form>
                </div>
            </div>
        </div>
        </div>
    </body>
</html>