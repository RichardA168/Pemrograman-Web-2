<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;

class PersonController extends BaseController
{
    public function index()
    {
        return view('login');
    }

    public function login()
    {
        $model = new UserModel();
        $username = request()->getPost('username');
        $email = request()->getPost('email');
        $password = request()->getPost('password');

        $dataPerson = $model->where(["username" => $username])->first();

        if($dataPerson){
            if(password_verify($password, $dataPerson['password'])){
                session()->set([
                    "username" => $username,
                    "isLoggedIn" => true
                ]);
                return redirect()->to(base_url('/'));
            }else{
                session()->setFlashdata(["pesan"=>"Login Error, Terdapat Kesalahan Input!"]);
                return redirect()->to(base_url('/login'));
            }
        }else{
            session()->setFlashdata(["pesan"=>"Login Error, Terdapat Kesalahan Input!"]);
            return redirect()->to(base_url('/login'));
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('login'));
    }
}
